<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="card">

                <div class="card-header">
                    <a href="#">
                        
                    </a>                    
                </div>

                <div class="card-body">
                    
                </div>
            </div>
            <br>

        </div>
    </div>
</div>
<script>
const NewsAPI = require('newsapi');
const newsapi = new NewsAPI('083ac16e3a7149258d263529559d49e6');

newsapi.v2.topHeadlines({
  q: 'trump',
  category: 'science',
  country: 'id'
}).then(response => {
  console.log(response);
  /*
    {
      status: "ok",
      articles: [...]
    }
  */
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>