<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($ref->judul); ?> | <?php echo e($ref->sumber); ?> | <?php echo e($ref->penulis); ?></div>

                <div class="card-body">
                    <?php echo e($ref->materi); ?>

                </div>

                <div class="card-footer">
                    <a class="btn btn-primary" href="<?php echo e(route('edit.ref', $ref)); ?>">Edit</a>
                </div>
            </div><br>

            <div class="card">
                    <div class="card-header"><h4>Analisa Unsur Intrinsik</h4></div>

                    <div class="card-body">                    
                        <?php if($ui == null): ?>
                        <form action="<?php echo e(route('unsur.store', $ref)); ?>" method="post" class="form-horizontal">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group has-feedback <?php echo e($errors->has('tema') ? ' has-error' : ''); ?>">
                                <label for="tema">Tema</label>
                                <textarea name="tema" rows="2" class="form-control" placeholder="Analisa Tema Referensi"><?php echo e(old('tema')); ?></textarea>
                                <?php if($errors->has('tema')): ?>
                                    <span class="help-block">
                                        <p><?php echo e($errors->first('tema')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group has-feedback <?php echo e($errors->has('tokoh') ? ' has-error' : ''); ?>">
                                <label for="tokoh">Tokoh</label>
                                <textarea name="tokoh" rows="2" class="form-control" placeholder="Analisa Tokoh Referensi"><?php echo e(old('tokoh')); ?></textarea>
                                <?php if($errors->has('tokoh')): ?>
                                    <span class="help-block">
                                        <p><?php echo e($errors->first('tokoh')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group has-feedback <?php echo e($errors->has('alur') ? ' has-error' : ''); ?>">
                                <label for="alur">Alur</label>
                                <textarea name="alur" rows="2" class="form-control" placeholder="Analisa Alur Referensi"><?php echo e(old('alur')); ?></textarea>
                                <?php if($errors->has('alur')): ?>
                                    <span class="help-block">
                                        <p><?php echo e($errors->first('alur')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group has-feedback <?php echo e($errors->has('latar') ? ' has-error' : ''); ?>">
                                <label for="latar">Latar</label>
                                <textarea name="latar" rows="2" class="form-control" placeholder="Analisa Latar Referensi"><?php echo e(old('latar')); ?></textarea>
                                <?php if($errors->has('latar')): ?>
                                    <span class="help-block">
                                        <p><?php echo e($errors->first('latar')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group has-feedback <?php echo e($errors->has('amanat') ? ' has-error' : ''); ?>">
                                <label for="amanat">Amanat</label>
                                <textarea name="amanat" rows="2" class="form-control" placeholder="Analisa Amanat Referensi"><?php echo e(old('amanat')); ?></textarea>
                                <?php if($errors->has('amanat')): ?>
                                    <span class="help-block">
                                        <p><?php echo e($errors->first('amanat')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            <input type="submit" value="Submit" class="btn btn-primary">
                        </form>
                        <table class="table table-borderless">
                            <thead>
                                <tr>
                                  <th scope="col"></th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <th scope="row" style="height: 320px"></th>
                                </tr>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <?php $__currentLoopData = $ref->unsur_instrinsik()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label for="tema"><strong>Tema</strong></label>
                        <p><?php echo e($uis->tema); ?></p>                        
                        <label for="tokoh"><strong>Tokoh</strong></label>
                        <p><?php echo e($uis->tokoh); ?></p>
                        <label for="alur"><strong>Alur</strong></label>
                        <p><?php echo e($uis->alur); ?></p>
                        <label for="latar"><strong>Latar</strong></label>
                        <p><?php echo e($uis->latar); ?></p>
                        <label for="amanat"><strong>Amanat</strong></label>
                        <p><?php echo e($uis->amanat); ?></p>
                        <a href="<?php echo e(route('edit.ui', $ref)); ?>" class="btn btn-primary">Edit</a>
                        <button type="submit" class="btn btn-danger" data-toggle="modal" data-target="#delete">Hapus</button>
                        <?php echo $__env->make('uideletemodal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <table class="table table-borderless">
                            <thead>
                                <tr>
                                  <th scope="col"></th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <th scope="row" style="height: 320px"></th>
                                </tr>
                            </tbody>
                        </table>
                        <?php endif; ?>


                    </div>
                </div><br>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>