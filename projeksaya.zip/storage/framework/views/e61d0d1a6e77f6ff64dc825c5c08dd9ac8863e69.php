<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
                    <div class="card-header"><h4>Analisa Unsur Intrinsik</h4></div>

                    <div class="card-body">
                        <form action="<?php echo e(route('update.ui', $ui)); ?>" method="post" class="form-horizontal">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>

                            <div class="form-group has-feedback <?php echo e($errors->has('tema') ? ' has-error' : ''); ?>">
                                <label for="tema">Tema</label>
                                <textarea name="tema" rows="2" class="form-control" placeholder="Analisa Tema Referensi"><?php echo e($ui->tema); ?></textarea>
                                <?php if($errors->has('tema')): ?>
                                    <span class="help-block">
                                        <p><?php echo e($errors->first('tema')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group has-feedback <?php echo e($errors->has('tokoh') ? ' has-error' : ''); ?>">
                                <label for="tokoh">Tokoh</label>
                                <textarea name="tokoh" rows="2" class="form-control" placeholder="Analisa Tokoh Referensi"><?php echo e($ui->tokoh); ?></textarea>
                                <?php if($errors->has('tokoh')): ?>
                                    <span class="help-block">
                                        <p><?php echo e($errors->first('tokoh')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group has-feedback <?php echo e($errors->has('alur') ? ' has-error' : ''); ?>">
                                <label for="alur">Alur</label>
                                <textarea name="alur" rows="2" class="form-control" placeholder="Analisa Alur Referensi"><?php echo e($ui->alur); ?></textarea>
                                <?php if($errors->has('alur')): ?>
                                    <span class="help-block">
                                        <p><?php echo e($errors->first('alur')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group has-feedback <?php echo e($errors->has('latar') ? ' has-error' : ''); ?>">
                                <label for="latar">Latar</label>
                                <textarea name="latar" rows="2" class="form-control" placeholder="Analisa Latar Referensi"><?php echo e($ui->latar); ?></textarea>
                                <?php if($errors->has('latar')): ?>
                                    <span class="help-block">
                                        <p><?php echo e($errors->first('latar')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group has-feedback <?php echo e($errors->has('amanat') ? ' has-error' : ''); ?>">
                                <label for="amanat">Amanat</label>
                                <textarea name="amanat" rows="2" class="form-control" placeholder="Analisa Amanat Referensi"><?php echo e($ui->amanat); ?></textarea>
                                <?php if($errors->has('amanat')): ?>
                                    <span class="help-block">
                                        <p><?php echo e($errors->first('amanat')); ?></p>
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            <input type="submit" value="Submit" class="btn btn-primary">
                        </form>  
                        <table class="table table-borderless">
                            <thead>
                                <tr>
                                  <th scope="col"></th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <th scope="row" style="height: 320px"></th>
                                </tr>
                            </tbody>
                        </table>   
                    </div>
                </div><br>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>