<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <?php echo e($post->judul); ?>

                    <a class="float-right" href="<?php echo e(route('edit', $post)); ?>">Edit</a>
                </div>

                <div class="card-body">
                    <?php echo e($post->materi); ?>

                </div>
            </div><br>

                <div class="card">
                    <div class="card-header"><h4>Komentar</h4></div>

                    <div class="card-body">
                        <?php $__currentLoopData = $post->comment()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h5><?php echo e($comment->user->name); ?> - <?php echo e($comment->created_at->diffForHumans()); ?>

                            <button class="float-right" type="submit" class="btn btn-xs btn-danger" data-toggle="modal" data-target="#delete">Hapus</button>
                            </h5>
                            <?php echo $__env->make('commentdeletemodal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <p><?php echo e($comment->message); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                    
                        <form action="<?php echo e(route('comment', $post)); ?>" method="post" class="form-horizontal">
                            <?php echo e(csrf_field()); ?>

                            <textarea name="message" id="" rows="2" class="form-control" placeholder="Berikan komentar..."></textarea>
                            <br>
                            <input type="submit" value="Submit" class="btn btn-primary">
                        </form>
                        <table class="table table-borderless">
                            <thead>
                                <tr>
                                  <th scope="col"></th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <th scope="row" style="height: 320px"></th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div><br>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>