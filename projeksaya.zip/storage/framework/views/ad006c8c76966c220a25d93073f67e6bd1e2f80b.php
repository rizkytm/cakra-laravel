<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Buat post</div>

                <div class="card-body">
            <form class="" action="<?php echo e(route('store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group has-feedback <?php echo e($errors->has('judul') ? ' has-error' : ''); ?>">
                <label for="">Judul</label>
                <input type="text" class="form-control" name="judul" placeholder="Post Title" value="<?php echo e(old('judul')); ?>">
                <?php if($errors->has('judul')): ?>
                    <span class="help-block">
                        <p><?php echo e($errors->first('judul')); ?></p>
                    </span>
                <?php endif; ?>
            </div>         
            
            <div class="form-group has-feedback <?php echo e($errors->has('materi') ? ' has-error' : ''); ?>">
                <label for="">Materi</label>
                <textarea name="materi" rows="5" class="form-control" placeholder="Post Content"><?php echo e(old('materi')); ?></textarea>
                <?php if($errors->has('materi')): ?>
                    <span class="help-block">
                        <p><?php echo e($errors->first('materi')); ?></p>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Save">
            </div>
        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>